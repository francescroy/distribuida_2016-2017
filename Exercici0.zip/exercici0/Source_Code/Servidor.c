/* 
 * File:   main.c
 * Author: francescroy
 *
 * Created on 21 de septiembre de 2016, 17:19
 */

#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
 
// GLOBALS!! //

int variable_compartida;
int vols_augmentar=0;
int vols_consultar=0;

static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER; 

char * port_escoltar;

static void * threadFunc (void *arg){

    int sockfd = socket (AF_INET, SOCK_STREAM, 0);
    
    struct sockaddr_in s_addr;
    memset (&s_addr, 0, sizeof (s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons ((atoi (port_escoltar))+1);
    s_addr.sin_addr.s_addr = INADDR_ANY;
    
    bind (sockfd, (void *) &s_addr, sizeof (s_addr));
    
    listen (sockfd, 1);
    
    socklen_t len = sizeof (s_addr);
    
    int newsock = accept (sockfd, (void *) &s_addr, &len);
    
    char * buff = malloc(sizeof(char)*1);
    
    while(1){
    
        recv(newsock,buff,1,MSG_WAITALL);
    
        if(buff[0]=='A'){
            
            vols_augmentar++;
            
            pthread_mutex_lock (&mtx);
            
            write(newsock,"\0\0\0\0\0",5);
        
        }else{
            
            vols_consultar++;
        
            pthread_mutex_lock (&mtx);
            
            sprintf(buff, "%d", variable_compartida); 
            
            write(newsock,buff,5);
            
        }
        
        
        
        
    }

    
    return NULL;
    

}


int main(int argc, char** argv) {
    
    // SERVIDOR
    
    port_escoltar = argv[1]; 
    
    pthread_mutex_lock (&mtx);
    
    int sockfd = socket (AF_INET, SOCK_STREAM, 0);
    
    struct sockaddr_in s_addr;
    memset (&s_addr, 0, sizeof (s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons (atoi (argv[1]));
    s_addr.sin_addr.s_addr = INADDR_ANY;
    
    bind (sockfd, (void *) &s_addr, sizeof (s_addr));
    
    listen (sockfd, 3);
    
    socklen_t len = sizeof (s_addr);
    
    int newsock = accept (sockfd, (void *) &s_addr, &len);
    
    
    
    
    
    int comprovacio=-1;
    int sockfd2;
    
    while(comprovacio==-1){
    
        sockfd2 = socket (AF_INET, SOCK_STREAM, 0);

        struct sockaddr_in s_addr2;  
        memset (&s_addr2, 0, sizeof (s_addr2));
        s_addr2.sin_family = AF_INET;
        s_addr2.sin_port = htons (atoi (argv[2]));
        inet_aton ("127.0.0.1", &s_addr2.sin_addr);

        comprovacio = connect (sockfd2, (void *) &s_addr2, sizeof (s_addr2));
        sleep(1);

    }
    
    
    
    pthread_t t1;
    pthread_create (&t1, NULL, threadFunc, NULL);
    


    char * buff = malloc(sizeof(char)*5);
    
    
    while(1){
    
        recv(newsock,buff,5,MSG_WAITALL);
        
        int valor= atoi(buff);
        
        if(vols_consultar==1){
            
            variable_compartida =valor;
            
            vols_consultar=0;
            
            sprintf(buff, "%d", valor);
        
            write(1,buff,5);
            write(1," - ",3);
            sleep(3);
        
            write(sockfd2, buff, 5);
            pthread_mutex_unlock (&mtx);
        
        }else if(vols_augmentar==1){
            
            sprintf(buff, "%d", valor+1); 
            
            vols_augmentar=0;
        
            write(1,buff,5);
            write(1," - ",3);
            sleep(3);
        
            write(sockfd2, buff, 5);
            pthread_mutex_unlock (&mtx);
        
        }else{
            
            sprintf(buff, "%d", valor);
        
            write(1,buff,5);
            write(1," - ",3);
            sleep(3);
        
            write(sockfd2, buff, 5);
        
        }
        
    
    }
    
    
   
    

    return 0;
}

