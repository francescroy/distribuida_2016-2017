/* 
 * File:   main.c
 * Author: francescroy
 *
 * Created on 21 de septiembre de 2016, 17:08
 */

#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h> 


/*
 * 
 */
int main(int argc, char** argv) {
    
    
    // Clar com que hi ha el tema de que nomes faras l'actualitzacio quan tens el token, si posessis un condicio de que la variable no pot ser mes petita que 0
    // Quan l'intentes fer no el deixaria, SI UN FA -10€ I UN ALTRE TAMBE I NOMES QUEDEN 11 NOMES DEIXARA A UN
    
    // Aquesta variable podria ser una taula d'una base de dades
    
    int sockfd;
    
    sockfd = socket (AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in s_addr;
    memset (&s_addr, 0, sizeof (s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons (atoi (argv[1]));
    inet_aton ("127.0.0.1", &s_addr.sin_addr);

    connect (sockfd, (void *) &s_addr, sizeof (s_addr));
        
    
    
    
    // MISSATGES QUE S'ENVIARAN:
    
    char * msg =  malloc(sizeof(char)*1); 
    
    msg[0]='A';
    
    char * msg2 = malloc(sizeof(char)*1); 
    
    msg2[0]='V';
    
    
    
    
    // PER AGAFAR INPUT DE L'USUARI:
    
    char * str1 = malloc(sizeof(char)*1); 
    
    str1[0]='\0';
    
    char * str2 = malloc(sizeof(char)*1); 
    
    str2[0]='\0';
    
    
    
    // EL QUE ENS TORNARA EL SERVER:
    
    char * resposta = malloc(sizeof(char)*5);
    
    

    while(1){
    
        write(1,"Si vols augmentar apreta: A, si vols veure apreta: V -> ",56);

        read(0,str1,1);
        read(0,str2,1); // Per el \n...

        if(str1[0]=='A'){

            write (sockfd, msg, 1); // NO CAL PASSAR DE QUAN AUGMENTES JA QUE NOMES ES POT FER +1
            
            write (1, "\nEsperant resposta del servidor...\n\n",36); 
            
            recv(sockfd,resposta,5,MSG_WAITALL);

        }else{

            write (sockfd, msg2, 1);
            
            write (1, "\nEsperant resposta del servidor...\n",35); 
            
            recv(sockfd,resposta,5,MSG_WAITALL);
            
            write(1,"\n",1);
            write(1,"El valor de la variable es: ",28);
            write(1,resposta,5);
            write(1,"\n",1);
            write(1,"\n",1);

        }
    
    }
    
    
    
    

    return 0;
}

