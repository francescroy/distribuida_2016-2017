/* 
 * File:   main.c
 * Author: francescroy
 *
 * Created on 21 de septiembre de 2016, 17:19
 */

#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <unistd.h>

/*
 * 
 */
int main(int argc, char** argv) {
    
    // SERVIDOR
    
    int sockfd2 = socket (AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in s_addr2;  
    memset (&s_addr2, 0, sizeof (s_addr2));
    s_addr2.sin_family = AF_INET;
    s_addr2.sin_port = htons (atoi (argv[2]));
    inet_aton ("127.0.0.1", &s_addr2.sin_addr);

    connect (sockfd2, (void *) &s_addr2, sizeof (s_addr2));
        
    
    
    
    int sockfd = socket (AF_INET, SOCK_STREAM, 0);
    
    struct sockaddr_in s_addr;
    memset (&s_addr, 0, sizeof (s_addr));
    s_addr.sin_family = AF_INET;
    s_addr.sin_port = htons (atoi (argv[1]));
    s_addr.sin_addr.s_addr = INADDR_ANY;
    
    bind (sockfd, (void *) &s_addr, sizeof (s_addr));
    
    listen (sockfd, 3);
    
    socklen_t len = sizeof (s_addr);
    
    int newsock = accept (sockfd, (void *) &s_addr, &len);
    
    
    
    
    char * buff = malloc(sizeof(char)*5);
    
    buff[0]='0';
    buff[1]='\0';
    buff[2]='\0';
    buff[3]='\0';
    buff[4]='\0';
    
    // Anem a fer la prova que es passin un numero i que cada server fagi +1
    
    while(1){
    
        write(sockfd2, buff, 5);
        
        recv(newsock,buff,5,MSG_WAITALL);
        
        int valor= atoi(buff);
        sprintf(buff, "%d", valor);
        
        write(1,buff,5); 
        write(1," - ",3);
        sleep(3);
        
        
    
    }
    
    
   
    
    
    
    
    
    
    
        
    
    
    
    
    
   
    

    return 0;
}

