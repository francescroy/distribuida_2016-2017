/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disssstjava2;

import java.util.Scanner;


/**
 *
 * @author francescroy
 */
public class DisssstJAVA2 {
    
    
    
    
    
    
    public static int mida_array=1000000;
    public static int num_threads=10;   
    
    
    
    
    
    
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        
        int[] array_a_passar = new int[mida_array];
        
        int i;
        
        for(i=0;i<mida_array;i++){
        
            array_a_passar[i]=i;
        
        }
        
        
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.print("Diga'm un numero del 0 al "+(mida_array-1)+" i et dire on es: ");
        int n = reader.nextInt();
        
        int casella = cercaParallela(n,array_a_passar,num_threads);
        
        System.out.println("Esta a la casella: "+casella);
        
        
        
        
    }
    
    public static int cercaParallela(int aBuscar, int[] Array, int NumThreads) throws InterruptedException{
        
        
        
        Resultat res = new Resultat();
        res.resultat=-1;
        
        
        
        Thread1[] array_threads = new Thread1[NumThreads];
        
        int i;
        
        for(i=0;i<NumThreads;i++){
        
            int[] array_a_passar = new int[Array.length/NumThreads];
            
            int j;
            
            for(j=0;j<(Array.length/NumThreads);j++){
                
                
                array_a_passar[j]= Array[i*(Array.length/NumThreads) + j];
                
            
            }
            
            array_threads[i] = new Thread1(array_a_passar,aBuscar, i,res); 
        
        }
    
        
        
        
        
        
        
        res.inici_temps= System.nanoTime();
        
        
        
        
        
        for(i=0;i<NumThreads;i++){
        
            array_threads[i].start();
        
        }
        
        
        
        
        for(i=0;i<NumThreads;i++){
        
            array_threads[i].join();
        
        }
        
        System.out.println("Resultat trobat en: "+(res.fi_temps-res.inici_temps)+" ns");
        
        return res.resultat;
    
    }
    
}










class Thread1 extends Thread{
    
    public int[] array_a_passar;
    public int num_a_buscar;
    public int quin_thread_soc;
    public Resultat res;

    public Thread1(int[] array_a_passar, int num_a_buscar, int quin_thread_soc,Resultat res){
    
        this.array_a_passar=array_a_passar;
        this.num_a_buscar=num_a_buscar;
        this.quin_thread_soc= quin_thread_soc;
        this.res=res;
    
    }
    
    public void run() {
        
        
        
        int i;

        for(i=0;i<array_a_passar.length;i++){

            if(array_a_passar[i]==this.num_a_buscar){
                
                this.res.resultat=(i+this.quin_thread_soc*array_a_passar.length);
                
                this.res.fi_temps= System.nanoTime(); 

            }

        }
                    
    }

}






class Resultat{

    public long inici_temps;
    
    public long fi_temps;
    
    public int resultat;

}
