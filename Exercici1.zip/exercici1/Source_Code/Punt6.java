

package disssstjava5;


import java.util.LinkedList;
import java.util.concurrent.ThreadLocalRandom;


/**
 *
 * @author francescroy
 *
 */

public class DisssstJAVA5 {
 
    
    
    
    public static int mida_array = 2048; // HA DE SER UNA POTENCIA DE 2!! 
    
    
    
    
    public static void main(String[] args) throws InterruptedException {
        
        
        
        int[] array_a_ordenar = new int[mida_array];
        
        
        
        // GENEREM ARRAY DESORDENAT
        
        for(int i=0;i<mida_array;i++){
        
            array_a_ordenar[i]=ThreadLocalRandom.current().nextInt(0, 1000);
            //System.out.println(array_a_ordenar[i]);
        
        }
        
        int[] array_ordenat = mergeSort(array_a_ordenar);
        
        // JA ORDENAT!
        
        System.out.println();
        
        
        for(int i=0;i<mida_array;i++){
        
            //System.out.println(array_ordenat[i]);
        
        }
        
        
    }
    
    public static int[] mergeSort(int[] array_a_ordenar ) throws InterruptedException{
    
        
        
            int[] sub_array_1 = new int[array_a_ordenar.length/2];
            int[] sub_array_2 = new int[array_a_ordenar.length/2];
            
            
            
            for(int i=0;i<(array_a_ordenar.length/2);i++){

                sub_array_1[i]=array_a_ordenar[i];
                
            }
         
            
            for(int i=(array_a_ordenar.length/2),j=0;i<array_a_ordenar.length;i++,j++){
            
                sub_array_2[j]=array_a_ordenar[i];
            
            }
            
            ThreadMerge t1 = new ThreadMerge(sub_array_1);
            ThreadMerge t2 = new ThreadMerge(sub_array_2);
            
            t1.start();
            t2.start();
            
            t1.join();
            t2.join();
            
            
            int[] res1 = t1.getRes_a_tornar();
            int[] res2 = t2.getRes_a_tornar();
            
            int[] res_a_tornar = new int[(res1.length*2)];
            
            
            LinkedList<Integer> l1 = new LinkedList<>();
            
            for(int i=0; i<res1.length; i++){l1.add(res1[i]);}
            
            LinkedList<Integer> l2 = new LinkedList<>();
            
            for(int i=0; i<res2.length; i++){l2.add(res2[i]);}
            
            LinkedList<Integer> l_a_tornar = new LinkedList<>();
            
            
            
            while(!l1.isEmpty() && !l2.isEmpty()){
            
                
                if(l1.peek()>l2.peek()){
                
                    l_a_tornar.add(l2.poll());
                
                }else{
                
                    l_a_tornar.add(l1.poll());
                
                }
            }
            
            while(!l1.isEmpty()){
            
                    l_a_tornar.add(l1.poll());
                
            }
            
            while(!l2.isEmpty()){
            
                    l_a_tornar.add(l2.poll());
                
            }
            
            
            for(int i=0; i<(res1.length*2);i++){
            
                res_a_tornar[i]= l_a_tornar.get(i);
                
            }
            
            return res_a_tornar;
        
        
    
    }
    
}


class ThreadMerge extends Thread{
    
    private int[] array_a_ordenar;
    
    private int[] res_a_tornar;
    
    public ThreadMerge(int[] array_a_ordenar){
    
        this.array_a_ordenar=array_a_ordenar;
    
    }
    
    @Override
    public void run() {
        
        
        if(this.array_a_ordenar.length!=1){
        
            
            int[] sub_array_1 = new int[this.array_a_ordenar.length/2];
            int[] sub_array_2 = new int[this.array_a_ordenar.length/2];
            
            
            
            for(int i=0;i<(this.array_a_ordenar.length/2);i++){

                sub_array_1[i]=this.array_a_ordenar[i];
                
            }
         
            
            for(int i=(this.array_a_ordenar.length/2),j=0;i<this.array_a_ordenar.length;i++,j++){
            
                sub_array_2[j]=this.array_a_ordenar[i];
            
            }
            
            ThreadMerge t1 = new ThreadMerge(sub_array_1);
            ThreadMerge t2 = new ThreadMerge(sub_array_2);
            
            t1.start();
            t2.start();
            
            try { t1.join(); } catch (InterruptedException ex) {}
            try { t2.join(); } catch (InterruptedException ex) {}
            
            
            int[] res1 = t1.getRes_a_tornar();
            int[] res2 = t2.getRes_a_tornar();
            
            res_a_tornar = new int[(res1.length*2)];
            
            
            LinkedList<Integer> l1 = new LinkedList<>();
            
            for(int i=0; i<res1.length; i++){l1.add(res1[i]);}
            
            LinkedList<Integer> l2 = new LinkedList<>();
            
            for(int i=0; i<res2.length; i++){l2.add(res2[i]);}
            
            LinkedList<Integer> l_a_tornar = new LinkedList<>();
            
            
            
            while(!l1.isEmpty() && !l2.isEmpty()){
            
                
                if(l1.peek()>l2.peek()){
                
                    l_a_tornar.add(l2.poll());
                
                }else{
                
                    l_a_tornar.add(l1.poll());
                
                }
            }
            
            while(!l1.isEmpty()){
            
                    l_a_tornar.add(l1.poll());
                
            }
            
            while(!l2.isEmpty()){
            
                    l_a_tornar.add(l2.poll());
                
            }
            
            
            for(int i=0; i<(res1.length*2);i++){
            
                res_a_tornar[i]= l_a_tornar.get(i);
                
            }
            
            
        
        
        
        
        }else{
        
            this.res_a_tornar = new int[1];
            
            this.res_a_tornar[0] = this.array_a_ordenar[0];
            
            
        
        }
        
        
        
                    
    }

    /**
     * @return the res_a_tornar
     */
    public int[] getRes_a_tornar() {
        return res_a_tornar;
    }

    /**
     * @param res_a_tornar the res_a_tornar to set
     */
    public void setRes_a_tornar(int[] res_a_tornar) {
        this.res_a_tornar = res_a_tornar;
    }

    

}
