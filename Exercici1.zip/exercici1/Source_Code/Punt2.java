/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disssstjava;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author francescroy
 */
public class DisssstJAVA {

    
    
    
    
    
    public static int mida_array=1000000;
    
    
    
    
    
    
    public static void main(String[] args) throws InterruptedException {
        
        ArrayList<Integer> array = new ArrayList<>();

        int i;
        
        for(i=0;i<mida_array;i++){
        
            array.add(i);
        
        }
        
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.print("Diga'm un numero del 0 al "+(mida_array-1)+": ");
        int num_a_buscar = reader.nextInt();
        
        Thread1 t1 = new Thread1(array,num_a_buscar);
        Thread2 t2 = new Thread2(array,num_a_buscar);
        
        t1.start();
        t2.start();
        
        t1.join();
        t2.join();
        
        
        
    }
    
}

class Thread1 extends Thread{
    
    public ArrayList<Integer> array;
    public int num_a_buscar;

    public Thread1(ArrayList<Integer> array, int num_a_buscar){
    
        this.array=array;
        this.num_a_buscar=num_a_buscar;
    
    }
    
    public void run() {
        
        int i;
        
        for(i=0;i<array.size();i++){
        
            if(this.array.get(i)==this.num_a_buscar){
            
                System.out.println("Thread que comença pel principi de l'Arraylist l'ha trobat!!!");
                
                break;
            }
        
        }
        
        
    }


}


class Thread2 extends Thread{

    public ArrayList<Integer> array;
    public int num_a_buscar;
    
    
    public Thread2(ArrayList<Integer> array, int num_a_buscar){
    
        this.array=array;
        this.num_a_buscar=num_a_buscar;
    
    }
    
    public void run() {
        
        
        
        int i;
        
        for(i=(array.size()-1);i>=0;i--){
        
            
            if(this.array.get(i)==this.num_a_buscar){
            
                System.out.println("Thread que comença pel final de l'Arraylist l'ha trobat!!!");
                
                break;
            }
        
        }
        
        
        
    }


}