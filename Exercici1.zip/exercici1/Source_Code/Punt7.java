

package disssstjava4;


import java.util.LinkedList;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author francescroy
 *
 */

public class DisssstJAVA4 {

    
    
    
    public static int mida_array = 2048; // HA DE SER UNA POTENCIA DE 2!!
    
    
    
    
    public static void main(String[] args) {
        
        
        
        int[] array_a_ordenar = new int[mida_array];
        
        
        
        // GENEREM ARRAY DESORDENAT
        
        for(int i=0;i<mida_array;i++){
        
            array_a_ordenar[i]=ThreadLocalRandom.current().nextInt(0, 1000);
            //System.out.println(array_a_ordenar[i]);
        
        }
        
        int[] array_ordenat = mergeSort(array_a_ordenar);
        
        // JA ORDENAT!
        
        System.out.println();
        
        
        for(int i=0;i<mida_array;i++){
        
            //System.out.println(array_ordenat[i]);
        
        }
        
        
    }
    
    public static int[] mergeSort(int[] array_a_ordenar ){
    
        if(array_a_ordenar.length!=1){
        
            int[] sub_array_1 = new int[array_a_ordenar.length/2];
            int[] sub_array_2 = new int[array_a_ordenar.length/2];
            
            
            
            for(int i=0;i<(array_a_ordenar.length/2);i++){

                sub_array_1[i]=array_a_ordenar[i];
                
            }
         
            
            for(int i=(array_a_ordenar.length/2),j=0;i<array_a_ordenar.length;i++,j++){
            
                sub_array_2[j]=array_a_ordenar[i];
            
            }
            
            int[] res1 = mergeSort(sub_array_1);
            int[] res2 = mergeSort(sub_array_2);
            
            int[] res_a_tornar = new int[(res1.length*2)];
            
            
            
            
            LinkedList<Integer> l1 = new LinkedList<>();
            
            for(int i=0; i<res1.length; i++){l1.add(res1[i]);}
            
            LinkedList<Integer> l2 = new LinkedList<>();
            
            for(int i=0; i<res2.length; i++){l2.add(res2[i]);}
            
            LinkedList<Integer> l_a_tornar = new LinkedList<>();
            
            
            
            while(!l1.isEmpty() && !l2.isEmpty()){
            
                
                if(l1.peek()>l2.peek()){
                
                    l_a_tornar.add(l2.poll());
                
                }else{
                
                    l_a_tornar.add(l1.poll());
                
                }
            }
            
            while(!l1.isEmpty()){
            
                    l_a_tornar.add(l1.poll());
                
            }
            
            while(!l2.isEmpty()){
            
                    l_a_tornar.add(l2.poll());
                
            }
            
            
            for(int i=0; i<(res1.length*2);i++){
            
                res_a_tornar[i]= l_a_tornar.get(i);
                
            }
            
            return res_a_tornar;
        
        }else{
        
            int[] una_sola_casella = new int[1];
            
            una_sola_casella[0] = array_a_ordenar[0];
            
            return una_sola_casella;
        
        }
    
        
    
    
    }
    
}
