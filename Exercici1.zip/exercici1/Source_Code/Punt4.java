/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package disssstjava3;

import java.util.Scanner;


/**
 *
 * @author francescroy
 */
public class DisssstJAVA3 {
    
    
    
    
    
    
    
    
    public static int mida_array=1000000;
    public static int num_threads=10;

    
    
    
    
    
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        
        int[] array_a_passar = new int[mida_array];
        
        int i;
        
        for(i=0;i<mida_array;i++){
        
            array_a_passar[i]=i;
        
        }
        
        
        Scanner reader = new Scanner(System.in);  // Reading from System.in
        System.out.print("Diga'm un numero del 0 al "+(mida_array-1)+" i et dire on es: ");
        int n = reader.nextInt();
        
        int casella = cercaParallela(n,array_a_passar,num_threads);
        
        System.out.println("Esta a la casella: "+casella);
        
        
        
        
    }
    
    public static int cercaParallela(int aBuscar, int[] Array, int NumThreads) throws InterruptedException{
        
        
        
        Resultat res = new Resultat();
        res.resultat=-1;
        
        
        
        Thread1[] array_threads = new Thread1[NumThreads];
        
        int i;
        
        for(i=0;i<NumThreads;i++){
        
            array_threads[i] = new Thread1(Array,aBuscar, i,res,(i*(Array.length/NumThreads)),((i+1)*(Array.length/NumThreads))-1, NumThreads); 
        
        }
    
        
        
        
        
        res.inici_temps= System.nanoTime();
        
        
        
        for(i=0;i<NumThreads;i++){
        
            array_threads[i].start();
        
        }
        
        
        for(i=0;i<NumThreads;i++){
        
            array_threads[i].join();
        
        }
        
        System.out.println("Resultat trobat en: "+(res.fi_temps-res.inici_temps)+" ns");
        
        return res.resultat;
    
    }
    
}










class Thread1 extends Thread{
    
    public int[] array_a_passar;
    public int num_a_buscar;
    public int quin_thread_soc;
    public Resultat res;
    public int inici;
    public int fi;
    public int numThreads;

    public Thread1(int[] array_a_passar, int num_a_buscar, int quin_thread_soc,Resultat res,int inici,int fi,int numThreads){
    
        this.array_a_passar=array_a_passar;
        this.num_a_buscar=num_a_buscar;
        this.quin_thread_soc= quin_thread_soc;
        this.res=res;
        this.inici=inici;
        this.fi=fi;
        this.numThreads=numThreads;
    
    }
    
    public void run() {
       
        int i,j=0;

        for(i=inici;i<=fi;i++,j++){

            if(array_a_passar[i]==this.num_a_buscar){
                
                this.res.resultat=(j+this.quin_thread_soc*(array_a_passar.length/numThreads));
                
                this.res.fi_temps= System.nanoTime();  

            }

        }
                    
    }

}






class Resultat{
    
    
    public long inici_temps;
    
    public long fi_temps;
    
    public int resultat;

}
