/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicast2b;

/**
 *
 * @author francescroy
 */
public class LamportClock {
 
    public int c;
    public int myid;
    
    public LamportClock(int myid){
        
        this.myid=myid;
        c=1;
    }
    public int getValue(){
        return c;
    }
    public void tick(){
        c=c+1;
    }
    public void receiveAction(int src, int sentValue){
        c = Math.max(c, sentValue)+1;
    } 
    
}
