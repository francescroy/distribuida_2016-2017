

package multicast4b;


import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.Semaphore;




public class Multicast4B {
    
    public static void main(String[] args) throws IOException, InterruptedException {
        
        MulticastServer s1 = new MulticastServer();
        
        s1.comencarThreads(); // Thread que agafa trames i no fa res mes, ja que hi ha un dels dos threads de la clase DosThreads...
                              // Com que un dels dos threads de la clase DosThreads quedara bloquejat durant un moment (quan estas a la CZ)
                              // i no ens volem perdre paquets, tenim un thread petit que sempre funciona!
                              // Els dos threads de la clase DosThreads són els importants

        DosThreads dt = new DosThreads(s1);
        
        dt.start(); 
        
        dt.run2(); // dt.start2();
    
    } 
    
}



/////////////////////////////

/////////////////////////////

/////////////////////////////




class DosThreads extends Thread{

    public MulticastServer s1;
    
    public Semaphore semafor_especial;
    
    public DosThreads(MulticastServer s1){
    
        this.s1=s1;
        
        this.semafor_especial = new Semaphore(1);
    
    }
    
    public void run(){
        
        // Preparem socket que ens servira per enviar trama al HW per dir que ja estem
        DatagramSocket socket=null;
        InetAddress group=null;
        
        try{
            socket = new DatagramSocket(7007);
            group = InetAddress.getByName("230.0.3.1");
        }catch(Exception e){}
    
        
        while(true){
            
            // Esperem que el HW ens avisi per començar
            try{
                MulticastSocket socket_per_comencar = new MulticastSocket(7003);
                InetAddress address_per_comencar = InetAddress.getByName("230.0.3.1"); 
                socket_per_comencar.joinGroup(address_per_comencar);
                DatagramPacket packet_per_comencar;
                byte[] buf = new byte[256];
                packet_per_comencar = new DatagramPacket(buf, buf.length);
                socket_per_comencar.receive(packet_per_comencar);
            }catch(Exception e){}
            
            
            // Intentem accedir a la CZ!
            try {this.s1.requestCS();} catch (Exception ex) {} 
            
            
            try { this.semafor_especial.acquire();} catch (Exception ex) {} // Aquest semafor es per no tractar trames que ens arriben un cop entrem a la zona critica
            
            // CZ!
            for(int y=0;y<10;y++){
            
                System.out.println("Proces lightweight B3"); 
                try {Thread.sleep(1000);} catch (InterruptedException ex) {}
            
            }
            
            System.out.println("- - - - - - - - - - - - - - - - - - - - -");
                
            
            try {this.s1.releaseCS();} catch (Exception ex) {} 
            
            try { this.semafor_especial.release();} catch (Exception ex) {} // Aquest semafor es per no tractar trames que ens arriben un cop entrem a la zona critica

            
            
            
            
            
            // Avisem al HW que ja estem.
            try{
                byte[] buf = new byte[256];

                DatagramPacket packet;

                packet = new DatagramPacket(buf, buf.length, group, 7004);  
                socket.send(packet);
            }catch(Exception e){}
            
            
        }
    
    
    }
    
    public void run2() throws SocketException{
    
    
        while(true){
                
            if(!this.s1.llista_de_trames.isEmpty()){
                
                try { this.semafor_especial.acquire();} catch (Exception ex) {}
                
                int jo_soc = this.s1.c.myid;
                
                String tag = this.s1.llista_de_trames.get(0).tag;
                int timestamp = this.s1.llista_de_trames.get(0).timestamp;
                int source = this.s1.llista_de_trames.get(0).source;       
                int destination = this.s1.llista_de_trames.get(0).destination;
                
                if(tag.equals("okaaaay") && destination!=jo_soc){   this.s1.llista_de_trames.remove(0); 
                                                                    try { this.semafor_especial.release();} catch (Exception ex) {}
                                                                    continue; }
                
                this.s1.c.receiveAction(source, timestamp);
                
                if(tag.equals("request")){  
                    
                    if((this.s1.myts==1000000)||(timestamp<this.s1.myts)||((timestamp==this.s1.myts)&&(source< jo_soc))){
                                            
                                            this.s1.enviarTrama("okaaaay", this.s1.c.getValue(), jo_soc , source);
                    }else{
                    
                                            this.s1.pendingQ.add(source);  
                    
                    }                                                                                                    
                
                }
                
                
                if(tag.equals("okaaaay")){  
                    
                    this.s1.numOkay++;
                    if(this.s1.numOkay==(3-1)){
                        
                        this.s1.semafor.release();
                    
                    }
                    
                }
                
                
                
                 
                    
                this.s1.llista_de_trames.remove(0);
                
                try { this.semafor_especial.release();} catch (Exception ex) {}
                
            }
        
        }
    
    }
    
    


}


///////////// ////////////////// ////////////////// /////////////////
////// ////////////// //////////////// ///////////////// ////////////
//////////// /////////////// //////////////// ///////////////////////



class MulticastServer{

    public DatagramSocket socket;
    public InetAddress group;
    public ThreadPersonalitzat1 t1;
    //public ThreadPersonalitzat2 t2;
    public List<Trama> llista_de_trames;
    
    public Semaphore semafor;
    
    public int myts;
    public LamportClock c = new LamportClock(2);
    public LinkedList<Integer> pendingQ = new LinkedList<>(); 
    public int numOkay =0;
    
    public MulticastServer() throws IOException, InterruptedException {
        
        
        this.socket = new DatagramSocket(8449);
        this.group = InetAddress.getByName("230.0.4.1");
        this.llista_de_trames = Collections.synchronizedList(new LinkedList<Trama>());
        this.t1 = new ThreadPersonalitzat1(this.llista_de_trames);
        //this.t2 = new ThreadPersonalitzat2(this.llista_de_trames);
        
        this.semafor = new Semaphore(1);
        this.semafor.acquire();
        
        this.myts=1000000;
        
        
        
    }
    
    public void requestCS() throws SocketException, InterruptedException{
    
        this.c.tick();
        this.myts=this.c.getValue();
        this.enviarTrama("request", this.myts, this.c.myid, 5);
        this.numOkay=0;
        while(numOkay<(3-1)){
                                this.semafor.acquire();    
                                                        }
    
    }
    
    
    public void releaseCS () throws SocketException{
    
        this.myts=1000000;
        while(!this.pendingQ.isEmpty()){
        
            int pid = this.pendingQ.removeFirst();
            this.enviarTrama("okaaaay",this.c.getValue() , this.c.myid, pid);
        
        }
        
        
    }
    
    
    public void comencarThreads(){
    
        t1.start();
        //t2.start();
    
    }

    
    public void enviarTrama(String tag, int valor_a_pasar, int origen, int desti) throws SocketException {
        
        
        String valor_a_passar_string = valor_a_pasar +"";
        
        if(valor_a_passar_string.length()==1) valor_a_passar_string="000"+valor_a_passar_string;
        if(valor_a_passar_string.length()==2) valor_a_passar_string="00"+valor_a_passar_string;
        if(valor_a_passar_string.length()==3) valor_a_passar_string="0"+valor_a_passar_string;
        
        String a_enviar = tag + valor_a_passar_string + origen + "" + desti;
        
        
        try { 

            byte[] buf = new byte[256];

            buf = a_enviar.getBytes();

            DatagramPacket packet;

            packet = new DatagramPacket(buf, buf.length, group, 8446); // Aqui poses a tots els que li envies!!!
            socket.send(packet);

            packet = new DatagramPacket(buf, buf.length, group, 8448); // Aqui poses a tots els que li envies!!!
            socket.send(packet);


        } catch (Exception e) {}
        
	
    }
    
    
}


class ThreadPersonalitzat1 extends Thread{
    
    public List<Trama> llista_de_trames;
    
    public ThreadPersonalitzat1 (List<Trama> llista_de_trames){
    
        this.llista_de_trames=llista_de_trames;
    
    }
    
    public void run() {
    
            
        
            try {
                MulticastSocket socket_b = new MulticastSocket(8450);
                InetAddress address = InetAddress.getByName("230.0.4.1"); 
                socket_b.joinGroup(address);

                DatagramPacket packet;

                // get a few quotes
                while(true){

                    byte[] buf = new byte[256];
                    packet = new DatagramPacket(buf, buf.length);
                    
                    socket_b.receive(packet);
                    
                    /*
                    // Chapuza --
                    buf = new byte[256];
                    packet = new DatagramPacket(buf, buf.length);

                    socket_b.receive(packet); 
                    // Chapuza --
                    */

                    String received = new String(packet.getData(), 0, packet.getLength());
                    
                    String tag = received.substring(0, 7);
                    int timestamp = Integer.parseInt(received.substring(7, 11));
                    int source = Integer.parseInt(received.substring(11, 12));
                    int destination = Integer.parseInt(received.substring(12, 13));
                    
                    this.llista_de_trames.add(new Trama(tag,timestamp,source,destination));


                }

                
                
            } catch (Exception ex) {}
    
    }
}


//class ThreadPersonalitzat2 extends Thread{
//    
//    public List<Trama> llista_de_trames;
//    
//    public ThreadPersonalitzat2 (List<Trama> llista_de_trames){
//    
//        this.llista_de_trames=llista_de_trames;
//    
//    }
//    
//    public void run(){
//    
//        try {
//            MulticastSocket socket_b = new MulticastSocket(4449);
//            InetAddress address = InetAddress.getByName("232.0.0.1"); 
//            socket_b.joinGroup(address);
//
//            DatagramPacket packet;
//
//            // get a few quotes
//            while(true){
//
//                byte[] buf = new byte[256];
//                packet = new DatagramPacket(buf, buf.length);
//                
//                socket_b.receive(packet);
//                
//                /*
//                // Chapuza --
//                buf = new byte[256];
//                packet = new DatagramPacket(buf, buf.length);
//                
//                socket_b.receive(packet); 
//                // Chapuza --
//                */
//                
//                String received = new String(packet.getData(), 0, packet.getLength());
//                
//                String tag = received.substring(0, 7);
//                int timestamp = Integer.parseInt(received.substring(7, 11));
//                int source = Integer.parseInt(received.substring(11, 12));
//                int destination = Integer.parseInt(received.substring(12, 13));
//                
//                this.llista_de_trames.add(new Trama(tag,timestamp,source,destination));
//                
//
//            }
//
//            
//        } catch (Exception ex) {}
//    
//    
//    }
//    
//    
//    
//}



class Trama {

    public int source;
    
    public int destination;
    
    public String tag;
    
    public int timestamp;

    public Trama (String tag, int timestamp,int source, int destination){
    
        this.destination=destination;
        this.tag=tag;
        this.timestamp=timestamp;
        this.source=source;
    
    }

}













