






package multicast3;


import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.Semaphore;



/**
 *
 * @author francescroy
 */
public class Multicast3 {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        
        MulticastServer s1 = new MulticastServer();
        
        s1.comencarThreads();

        DosThreads dt = new DosThreads(s1);
        
        dt.start(); 
        
        dt.run2(); // dt.start2();
    
    } 
    
}



/////////////////////////////

/////////////////////////////

/////////////////////////////




class DosThreads extends Thread{

    public MulticastServer s1;
    
    public Semaphore semafor_especial;
    
    public DosThreads(MulticastServer s1){
    
        this.s1=s1;
        
        this.semafor_especial = new Semaphore(1);
    
    }
    
    public void run(){
    
        DatagramSocket socket=null;
        InetAddress group=null;
        
        try{
            socket = new DatagramSocket(5006);
            group = InetAddress.getByName("230.0.1.1");
        }catch(Exception e){}
        
        
        while(true){
            
            try{
                MulticastSocket socket_per_comencar = new MulticastSocket(5002);
                InetAddress address_per_comencar = InetAddress.getByName("230.0.1.1"); 
                socket_per_comencar.joinGroup(address_per_comencar);
                DatagramPacket packet_per_comencar;
                byte[] buf = new byte[256];
                packet_per_comencar = new DatagramPacket(buf, buf.length);
                socket_per_comencar.receive(packet_per_comencar);
            }catch(Exception e){}
            
             

            try {this.s1.requestCS();} catch (Exception ex) {} 
              
            try { this.semafor_especial.acquire();} catch (Exception ex) {}
            
            for(int y=0;y<10;y++){
            
                System.out.println("Proces lightweight A2");  
                try {Thread.sleep(1000);} catch (InterruptedException ex) {}
            
            }
                
            System.out.println("- - - - - - - - - - - - - - - - - - - - -"); 
                 
            
            try {this.s1.releaseCS();} catch (Exception ex) {} 
            
            try { this.semafor_especial.release();} catch (Exception ex) {}
            
            
            
            // Avisem al heavyWeight que ja estem.
            try{
                byte[] buf = new byte[256];

                DatagramPacket packet;

                packet = new DatagramPacket(buf, buf.length, group, 5004);  
                socket.send(packet);
            }catch(Exception e){}
            
            
        }
    
    
    }
    
    public void run2() throws SocketException{
    
    
        while(true){
                
            if(!this.s1.llista_de_trames.isEmpty()){
                
                try { this.semafor_especial.acquire();} catch (Exception ex) {}
                
                int jo_soc = this.s1.v.my_id;
                
                String tag = this.s1.llista_de_trames.get(0).tag;
                int timestamp = this.s1.llista_de_trames.get(0).timestamp;
                int source = this.s1.llista_de_trames.get(0).source;       
                int destination = this.s1.llista_de_trames.get(0).destination;
                
                if(tag.equals("acknowl") && destination!=jo_soc){   this.s1.llista_de_trames.remove(0); 
                                                                    try { this.semafor_especial.release();} catch (Exception ex) {}
                                                                    continue; }
                
                this.s1.v.receiveAction(source, timestamp);
                
                if(tag.equals("request")){  this.s1.q[source] = timestamp; 
                                            this.s1.enviarTrama("acknowl", this.s1.v.getValue(jo_soc), jo_soc , source);}
                
                
                if(tag.equals("release")){  this.s1.q[source] = 1000000; 
                                                                                                                        }
                
                
                
                this.s1.semafor.release(); 
                    
                this.s1.llista_de_trames.remove(0);
                
                try { this.semafor_especial.release();} catch (Exception ex) {}
                
            }
        
        }
    
    }
    
    


}


///////////// ////////////////// ////////////////// /////////////////
////// ////////////// //////////////// ///////////////// ////////////
//////////// /////////////// //////////////// ///////////////////////



class MulticastServer{

    public DatagramSocket socket;
    public InetAddress group;
    public ThreadPersonalitzat1 t1;
    //public ThreadPersonalitzat2 t2;
    public List<Trama> llista_de_trames;
    
    public Semaphore semafor;
    
    public DirectClock v;
    public int[] q;
    
    public MulticastServer() throws IOException, InterruptedException {
        
        
        this.socket = new DatagramSocket(4447);
        this.group = InetAddress.getByName("230.0.0.1");
        this.llista_de_trames = Collections.synchronizedList(new LinkedList<Trama>());
        this.t1 = new ThreadPersonalitzat1(this.llista_de_trames);
        //this.t2 = new ThreadPersonalitzat2(this.llista_de_trames);
        
        this.semafor = new Semaphore(1);
        this.semafor.acquire();
        
        this.v = new DirectClock(3,1);
        this.q = new int[3];
        
        for(int i=0;i<3;i++) this.q[i] =1000000;
        
        
        
    }
    
    public void requestCS() throws SocketException, InterruptedException{
    
        this.v.tick();
        q[this.v.my_id] = v.getValue(this.v.my_id);
        this.enviarTrama("request", q[this.v.my_id], this.v.my_id, 5);
        while(!okayCS()){
                            this.semafor.acquire();
        }
    
    }
    
    
    public boolean okayCS(){
    
        for(int j=0;j<3;j++){
        
            if(isGreater(q[this.v.my_id],this.v.my_id,q[j],j)) return false;
            if(isGreater(q[this.v.my_id],this.v.my_id,v.getValue(j),j)) return false;
        
        }
        return true;
    }
    
    
    public boolean isGreater(int entry1, int pid1, int entry2, int pid2){
        
        if(entry2 == 1000000) return false;
        return ((entry1 > entry2) || ((entry1 == entry2) && (pid1>pid2)));
    
    }
    
    
    
    
    public void releaseCS () throws SocketException{
    
        q[this.v.my_id] = 1000000;
        this.enviarTrama("release", v.getValue(this.v.my_id), this.v.my_id, 5);
    
    }
    
    
    public void comencarThreads(){
    
        t1.start();
        //t2.start();
    
    }

    
    public void enviarTrama(String tag, int valor_a_pasar, int origen, int desti) throws SocketException {
        
        
        String valor_a_passar_string = valor_a_pasar +"";
        
        if(valor_a_passar_string.length()==1) valor_a_passar_string="000"+valor_a_passar_string;
        if(valor_a_passar_string.length()==2) valor_a_passar_string="00"+valor_a_passar_string;
        if(valor_a_passar_string.length()==3) valor_a_passar_string="0"+valor_a_passar_string;
        
        String a_enviar = tag + valor_a_passar_string + origen + "" + desti;
        
        
        try { 

            byte[] buf = new byte[256];

            buf = a_enviar.getBytes();

            DatagramPacket packet;

            packet = new DatagramPacket(buf, buf.length, group, 4446); // Aqui poses a tots els que li envies!!!
            socket.send(packet);

            packet = new DatagramPacket(buf, buf.length, group, 4450); // Aqui poses a tots els que li envies!!!
            socket.send(packet);


        } catch (Exception e) {}
        
	
    }
    
    
}


class ThreadPersonalitzat1 extends Thread{
    
    public List<Trama> llista_de_trames;
    
    public ThreadPersonalitzat1 (List<Trama> llista_de_trames){
    
        this.llista_de_trames=llista_de_trames;
    
    }
    
    public void run() {
    
            
        
            try {
                MulticastSocket socket_b = new MulticastSocket(4448);
                InetAddress address = InetAddress.getByName("230.0.0.1"); 
                socket_b.joinGroup(address);

                DatagramPacket packet;

                // get a few quotes
                while(true){

                    byte[] buf = new byte[256];
                    packet = new DatagramPacket(buf, buf.length);
                    
                    socket_b.receive(packet);
                    
                    /*
                    // Chapuza --
                    buf = new byte[256];
                    packet = new DatagramPacket(buf, buf.length);

                    socket_b.receive(packet); 
                    // Chapuza --
                    */

                    String received = new String(packet.getData(), 0, packet.getLength());
                    
                    String tag = received.substring(0, 7);
                    int timestamp = Integer.parseInt(received.substring(7, 11));
                    int source = Integer.parseInt(received.substring(11, 12));
                    int destination = Integer.parseInt(received.substring(12, 13));
                    
                    this.llista_de_trames.add(new Trama(tag,timestamp,source,destination));


                }

                
                
            } catch (Exception ex) {}
    
    }
}


//class ThreadPersonalitzat2 extends Thread{
//    
//    public List<Trama> llista_de_trames;
//    
//    public ThreadPersonalitzat2 (List<Trama> llista_de_trames){
//    
//        this.llista_de_trames=llista_de_trames;
//    
//    }
//    
//    public void run(){
//    
//        try {
//            MulticastSocket socket_b = new MulticastSocket(4450);         
//            InetAddress address = InetAddress.getByName("232.0.0.1"); 
//            socket_b.joinGroup(address);
//
//            DatagramPacket packet;
//
//            // get a few quotes
//            while(true){
//
//                byte[] buf = new byte[256];
//                packet = new DatagramPacket(buf, buf.length);
//                
//                socket_b.receive(packet);
//                
//                /*
//                // Chapuza --
//                buf = new byte[256];
//                packet = new DatagramPacket(buf, buf.length);
//                
//                socket_b.receive(packet); 
//                // Chapuza --
//                */
//                
//                String received = new String(packet.getData(), 0, packet.getLength());
//                
//                String tag = received.substring(0, 7);
//                int timestamp = Integer.parseInt(received.substring(7, 11));
//                int source = Integer.parseInt(received.substring(11, 12));
//                int destination = Integer.parseInt(received.substring(12, 13));
//                
//                this.llista_de_trames.add(new Trama(tag,timestamp,source,destination));
//                
//
//            }
//
//            
//        } catch (Exception ex) {}
//    
//    
//    }
//    
//    
//    
//}



class Trama {

    public int source;
    
    public int destination;
    
    public String tag;
    
    public int timestamp;

    public Trama (String tag, int timestamp,int source, int destination){
    
        this.destination=destination;
        this.tag=tag;
        this.timestamp=timestamp;
        this.source=source;
    }

}













