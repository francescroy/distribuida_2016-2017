/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multicast3;

/**
 *
 * @author francescroy
 */
public class DirectClock {

    public int[] clock;
    int my_id;

    public DirectClock(int num_proc, int id){
    
        my_id = id;
     
        clock = new int[num_proc];
        
        for(int i=0;i<num_proc;i++) clock[i]=0;
        
        clock[my_id]=1;
     
    }
   
    public int getValue(int i){

        return clock[i];

    }

    public void tick(){
    
        clock[my_id]++;
    
    }
    
    public void receiveAction(int sender, int sent_value){
    
        clock[sender] = this.tornaElMesGran(clock[sender], sent_value);
        clock[my_id] =  this.tornaElMesGran(clock[my_id], sent_value) + 1;
    }
    
    private int tornaElMesGran(int num1, int num2){
    
        if(num1>num2) return num1;
        
        return num2;
    
    }


}
