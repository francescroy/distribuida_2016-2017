/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heavyweightb;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;

/**
 *
 * @author francescroy
 */
public class HeavyweightB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException, SocketException, UnknownHostException, IOException {
        
        //Preparem el socket per parlar amb els LW quan volem que comencin
        DatagramSocket socket = new DatagramSocket(7000);
        InetAddress group = InetAddress.getByName("230.0.3.1");
        
        //Preparem el socket per parlar amb l'altre HW
        DatagramSocket socket_HW = new DatagramSocket(6003);
        InetAddress group_HW = InetAddress.getByName("230.0.2.1");
        
        while(true){
        
            esperarTramaAltreHW();
            
            byte[] buf = new byte[256];

            DatagramPacket packet;

            packet = new DatagramPacket(buf, buf.length, group, 7001); 
            socket.send(packet);

            packet = new DatagramPacket(buf, buf.length, group, 7002); 
            socket.send(packet);

            packet = new DatagramPacket(buf, buf.length, group, 7003); 
            socket.send(packet);
            
            
            try{
                MulticastSocket socket_per_comencar = new MulticastSocket(7004);
                InetAddress address_per_comencar = InetAddress.getByName("230.0.3.1"); 
                socket_per_comencar.joinGroup(address_per_comencar);
                DatagramPacket packet_per_comencar;
                
                packet_per_comencar = new DatagramPacket(buf, buf.length);
                
                socket_per_comencar.receive(packet_per_comencar);
                socket_per_comencar.receive(packet_per_comencar);
                socket_per_comencar.receive(packet_per_comencar);
            
            }catch(Exception e){}
            
            
            //Enviem la trama a l'altre HW perque ja hem acabat    
            DatagramPacket packet_HW;
            packet_HW = new DatagramPacket(buf, buf.length, group_HW, 6001); 
            socket_HW.send(packet_HW);
            
            
        
        }
        
    }
    
    public static void esperarTramaAltreHW(){
    
        try{
            MulticastSocket socket_per_comencar = new MulticastSocket(6002);
            InetAddress address_per_comencar = InetAddress.getByName("230.0.2.1"); 
            socket_per_comencar.joinGroup(address_per_comencar);
            DatagramPacket packet_per_comencar;
            byte[] buf = new byte[256];
            packet_per_comencar = new DatagramPacket(buf, buf.length);
            socket_per_comencar.receive(packet_per_comencar);
        }catch(Exception e){}
    
    }
    
}
