/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heavyweight;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.SocketException;
import java.net.UnknownHostException;


/**
 *
 * @author francescroy
 */
public class Heavyweight {

    /**
     * @param args the command line arguments
     * @throws java.net.SocketException
     * @throws java.net.UnknownHostException
     */
    public static void main(String[] args) throws SocketException, UnknownHostException, IOException, InterruptedException {
        
        //Preparem el socket per parlar amb els LW quan volem que comencin
        DatagramSocket socket = new DatagramSocket(5000);
        InetAddress group = InetAddress.getByName("230.0.1.1");
        
        //Preparem el socket per parlar amb l'altre HW
        DatagramSocket socket_HW = new DatagramSocket(6000);
        InetAddress group_HW = InetAddress.getByName("230.0.2.1");
        
        while(true){
        
            // Aquest HW1 es el que s'ha d'executar primer
            byte[] buf = new byte[256];


            DatagramPacket packet;

            packet = new DatagramPacket(buf, buf.length, group, 5001); 
            socket.send(packet);

            packet = new DatagramPacket(buf, buf.length, group, 5002); 
            socket.send(packet);

            packet = new DatagramPacket(buf, buf.length, group, 5003); 
            socket.send(packet);
            
            
            try{
                MulticastSocket socket_per_comencar = new MulticastSocket(5004);
                InetAddress address_per_comencar = InetAddress.getByName("230.0.1.1"); 
                socket_per_comencar.joinGroup(address_per_comencar);
                DatagramPacket packet_per_comencar;
                
                packet_per_comencar = new DatagramPacket(buf, buf.length);
                
                socket_per_comencar.receive(packet_per_comencar);
                socket_per_comencar.receive(packet_per_comencar);
                socket_per_comencar.receive(packet_per_comencar);
            
            }catch(Exception e){}
            
            
            //Enviem la trama a l'altre HW perque ja hem acabat    
            DatagramPacket packet_HW;
            packet_HW = new DatagramPacket(buf, buf.length, group_HW, 6002); 
            socket_HW.send(packet_HW);
            
            //Esperem a que l'altre HW acabi
            esperarTramaAltreHW();
            
            
            
        }
        
        
        
    }
    
    public static void esperarTramaAltreHW(){
    
        try{
            MulticastSocket socket_per_comencar = new MulticastSocket(6001);
            InetAddress address_per_comencar = InetAddress.getByName("230.0.2.1"); 
            socket_per_comencar.joinGroup(address_per_comencar);
            DatagramPacket packet_per_comencar;
            byte[] buf = new byte[256];
            packet_per_comencar = new DatagramPacket(buf, buf.length);
            socket_per_comencar.receive(packet_per_comencar);
        }catch(Exception e){}
    
    
    
    }
    
}


//class ThreadMissatge0 extends Thread{
//
//    public void run(){
//    
//        try{
//                MulticastSocket socket_per_comencar = new MulticastSocket(6001);
//                InetAddress address_per_comencar = InetAddress.getByName("224.0.1.1"); 
//                socket_per_comencar.joinGroup(address_per_comencar);
//                DatagramPacket packet_per_comencar;
//                byte[] buf = new byte[256];
//                packet_per_comencar = new DatagramPacket(buf, buf.length);
//                socket_per_comencar.receive(packet_per_comencar);
//            }catch(Exception e){}
//    
//    
//    
//    }
//
//}
//
//class ThreadMissatge1 extends Thread{
//
//    public void run(){
//    
//        try{
//                MulticastSocket socket_per_comencar = new MulticastSocket(6002);
//                InetAddress address_per_comencar = InetAddress.getByName("224.0.2.1"); 
//                socket_per_comencar.joinGroup(address_per_comencar);
//                DatagramPacket packet_per_comencar;
//                byte[] buf = new byte[256];
//                packet_per_comencar = new DatagramPacket(buf, buf.length);
//                socket_per_comencar.receive(packet_per_comencar);
//            }catch(Exception e){}
//    
//    
//    
//    }
//
//}
//
//class ThreadMissatge2 extends Thread{
//
//    public void run(){
//    
//        try{
//                MulticastSocket socket_per_comencar = new MulticastSocket(6003);
//                InetAddress address_per_comencar = InetAddress.getByName("224.0.3.1"); 
//                socket_per_comencar.joinGroup(address_per_comencar);
//                DatagramPacket packet_per_comencar;
//                byte[] buf = new byte[256];
//                packet_per_comencar = new DatagramPacket(buf, buf.length);
//                socket_per_comencar.receive(packet_per_comencar);
//            }catch(Exception e){}
//    
//    
//    
//    }
//
//}

